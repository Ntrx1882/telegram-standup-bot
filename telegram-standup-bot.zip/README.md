# Telegram Standup Bot

A simple Telegram bot that collects daily status updates from team members and sends a summary to a group chat (basic version).

## Features

- /start — greets the user
- /update — collects a short daily update (e.g. "Working on feature X", "Fixing a bug")
- Easy to expand: save to file, forward to group, or auto-summarize

## Example Usage

```
/update Finishing frontend fixes for the dashboard
```

## Requirements

- Python 3.10+
- `python-telegram-bot` v20+

## Setup

1. Install the required package:

```
pip install python-telegram-bot --upgrade
```

2. Get your bot token from [@BotFather](https://t.me/BotFather)

3. Set the token as an environment variable:

**Linux/macOS**
```bash
export TELEGRAM_BOT_TOKEN=your_token_here
```

**Windows (CMD)**
```cmd
set TELEGRAM_BOT_TOKEN=your_token_here
```

4. Run the bot:

```bash
python standup_bot.py
```

## To Do

- Store updates in a file or database
- Automatically compile daily summaries
- Send summaries to group chat
- Schedule daily prompts

---

Feel free to extend or adapt as needed!