from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hi! I'm your daily standup bot. Type /update to send your status.")

# Команда /update
async def update_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user.first_name
    status = " ".join(context.args)
    if status:
        # Здесь должен быть сбор и отправка данных (упрощённо)
        await update.message.reply_text(f"Thanks {user}, I’ve saved your update!")
    else:
        await update.message.reply_text("Please provide your update after the command, like: /update Working on bug fix.")

if __name__ == '__main__':
    # Получи токен бота из переменной окружения
    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("update", update_status))

    print("Bot is running...")
    app.run_polling()